import 'package:flutter/material.dart';
import 'web_view_container.dart';

class Home extends StatelessWidget {
  final _links = ['https://www.youtube.com/channel/UC0N2_iWkMtf63GPLf9yyS1w'];

  @override 
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            mainAxisAligment: MainAxisAligment.center,
            crossAxisAligment: CrossAxisAligment.stretch,
            children: _links.map((link)=> _urlButton(context, link)).tolist(),
          )
        )
      )
    ); 
  }
  Widget _urlButton(BuildContext context, String url) {
    return Container(
      padding: EdgeInsets.all(20.0),
      child: FlatButton(
        color: Thene.of(context).primaryColor,
        padding:EdgeInsets.symmetric(horizontal: 50.0, vertical: 15.0),
        child: Text(url),
        onPressed: () => _handleURLButtonPress(context, url),
    ));
  }

  void _handleURLButtonPress(BuildContext context, String url) {
    Navigator.push(context,
    MaterialPageRoute(builder: (context) => WebViewContainer(url)));
  }
}